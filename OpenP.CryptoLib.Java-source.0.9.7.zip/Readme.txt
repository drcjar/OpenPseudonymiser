You need Java v1.5 or higher.
Compile and test by running:
  ant
at the command prompt.
