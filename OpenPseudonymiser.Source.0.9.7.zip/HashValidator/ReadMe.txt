-- Internal Tool --

A simple app used to validate the hash created in the output file.
Not required as part of the build/release for OpenP

